const  express = require("express");

const app = express();

// app.get('/',(req,res)=>{
//     res.status(200).send("Hello I am Server Side")
// })

app.get('/',(req,res)=>{
    res.status(200).send({msg:'Hello I am Abhisek',app:'Natours'})
})

app.listen(8000, ()=>{
    console.log("Listen")
});
  
